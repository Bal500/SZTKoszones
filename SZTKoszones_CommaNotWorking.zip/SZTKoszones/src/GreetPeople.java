import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("ALL")
public class GreetPeople {
    String simpleStart = "Hello, ";
    String capitalStart = "HELLO, ";
    String result = "";
    List<String> standardNames = new ArrayList<>();
    List<String> capitalNames = new ArrayList<>();
    List<String> joinedNames = new ArrayList<>();

    String[] splittedNames = new String[256];

    public String greeter(String[] names) {
        //Check for names splitted by commas
        int didSplit = 0;
        for (int i = 0; i < names.length; i++) {
            if (names[i].contains(",")) {
                splittedNames = names[i].split(",");
                didSplit++;
            }
        }

        if (didSplit != 0) {
            for (int i = 0; i < splittedNames.length; i++) {
                joinedNames.add(splittedNames[i]);
            }
        }

        for (int i = 0; i < names.length; i++) {
            joinedNames.add(names[i]);
        }
        
        // In case of 1 input
        if (joinedNames.size() == 1) {
            /*
            Let's check whether the 2nd letter of the name is a capital
            YES: the entire name has to be spelled that way
            NO: the name has to be spelled 'correctly'
            */
            boolean capital = false;
            for (String name : names) {
                char actual = name.charAt(1);
                if (actual >= 'A' && actual <= 'Z') {
                    capital = true;
                }
            }

            if (capital) {
                result = capitalStart + joinedNames.get(0) + ".";
            }
            if (!capital) {
                result = simpleStart + joinedNames.get(0) + ".";
            }

            return result;
        }

        // In case of multiple inputs
        if (joinedNames.size() > 1) {
            /*
            Let's check whether the 2nd letter of the name is a capital
            YES: the entire name has to be spelled that way
            NO: the name has to be spelled 'correctly'
            */
            boolean capital = false;
            boolean standard = false;
            for (int i = 0; i < joinedNames.size(); i++) {
                 char actual = joinedNames.get(i).charAt(1);
                 if (actual >= 'A' && actual <= 'Z') {
                     capitalNames.add(joinedNames.get(i));
                     capital = true;
                 } else {
                     standardNames.add(joinedNames.get(i));
                     standard = true;
                    }
                 }

            if (capital && !standard) {
                result += capitalStart;
                for (int i = 0; i < joinedNames.size(); i++) {
                    // Until the penultimate run it draws commas, then uses 'AND'
                    if (i < joinedNames.size() - 1) {
                        result += joinedNames.get(i) + ", ";
                    }
                    if (i == joinedNames.size() - 1) {
                        result += "AND " + joinedNames.get(i) + ".";
                    }
                }
            }

            if (!capital) {
                result += simpleStart;
                for (int i = 0; i < joinedNames.size(); i++) {
                    // Until the penultimate run it draws commas, then uses 'and'
                    if (i < joinedNames.size() - 1) {
                        result += joinedNames.get(i) + ", ";
                    }
                    if (i == joinedNames.size() - 1) {
                        result += "and " + joinedNames.get(i) + ".";
                    }
                }
            }

            if (capital && standard) {
                result += simpleStart;
                for (int i = 0; i < standardNames.size(); i++) {
                    // Until the penultimate run it draws commas, then uses 'and'
                    if (i < standardNames.size() - 1) {
                        result += standardNames.get(i) + ", ";
                    }
                    if (i == standardNames.size() - 1) {
                        result += "and " + standardNames.get(i) + ".";
                    }
                }

                result += " AND " + capitalStart;
                for (int i = 0; i < capitalNames.size(); i++) {
                    // Until the penultimate run it draws commas, then uses 'AND'
                    if (i < capitalNames.size() - 1) {
                        result += capitalNames.get(i) + ", ";
                    }
                    if (i == capitalNames.size() - 1) {
                        result += "AND " + capitalNames.get(i) + ".";
                    }
                }
            }
            return result;
        }

        return("Hello, my friend.");
    }
}