import java.util.ArrayList;
import java.util.List;

public class GreetPeople {
    String simpleStart = "Hello, ";
    String capitalStart = "HELLO, ";
    String result = "";
    List<String> standardNames = new ArrayList<>();
    List<String> capitalNames = new ArrayList<>();

    List<String> joinedNames = new ArrayList<String>();

    public String greeter(String[] names) {
        // 1 bemenet esetén
        if (names.length == 1) {
            /*
            Nézzük meg a név második betűje nagy-e
            IGEN: az egész név az
            NEM: a név "helyesen" van írva
            */
            boolean capital = false;
            for (int i = 0; i < names.length; i++) {
                 char actual = names[i].charAt(1);
                if (actual >= 'A' && actual <= 'Z') {
                    capital = true;
                }
            }

            if (capital) {
                result = capitalStart + names[0] + ".";
            }
            if (!capital) {
                result = simpleStart + names[0] + ".";
            }

                return result;
        }

        if (names.length > 1) {
            /*
            Nézzük meg a név második betűje nagy-e
            IGEN: az egész név az
            NEM: a név "helyesen" van írva
            */
            boolean capital = false;
            boolean standard = false;
            for (int i = 0; i < names.length; i++) {
                 char actual = names[i].charAt(1);
                 if (actual >= 'A' && actual <= 'Z') {
                     capitalNames.add(names[i]);
                     capital = true;
                 } else {
                     standardNames.add(names[i]);
                     standard = true;
                    }
                 }

            if (capital && !standard) {
                result += capitalStart;
                for (int i = 0; i < names.length; i++) {
                    // Az utolsó előtti fordulóig rak vesszőket, utána az "and"-et
                    if (i < names.length - 1) {
                        result += names[i] + ", ";
                    }
                    if (i == names.length - 1) {
                        result += "AND " + names[i] + ".";
                    }
                }
            }

            if (!capital && standard) {
                result += simpleStart;
                for (int i = 0; i < names.length; i++) {
                    // Az utolsó előtti fordulóig rak vesszőket, utána az "and"-et
                    if (i < names.length - 1) {
                        result += names[i] + ", ";
                    }
                    if (i == names.length - 1) {
                        result += "and " + names[i] + ".";
                    }
                }
            }

            if (capital && standard) {
                result += simpleStart;
                for (int i = 0; i < standardNames.size(); i++) {
                    // Az utolsó előtti fordulóig rak vesszőket, utána az "and"-et
                    if (i < standardNames.size() - 1) {
                        result += standardNames.get(i) + ", ";
                    }
                    if (i == standardNames.size() - 1) {
                        result += "and " + standardNames.get(i) + ".";
                    }
                }

                result += " AND " + capitalStart;
                for (int i = 0; i < capitalNames.size(); i++) {
                    // Az utolsó előtti fordulóig rak vesszőket, utána az "and"-et
                    if (i < capitalNames.size() - 1) {
                        result += capitalNames.get(i) + ", ";
                    }
                    if (i == capitalNames.size() - 1) {
                        result += "AND " + capitalNames.get(i) + ".";
                    }
                }
            }
                return result;
        }

        return("Hello, my friend.");
    }
}