import static org.junit.Assert.assertEquals;

import org.junit.Test;
@SuppressWarnings("ALL")
public class test {
    @Test
    public void ShouldGreet() {
        assertEquals("Hello, my friend.", new GreetPeople().greeter(new String[]{}));
        assertEquals("Hello, Dincso.", new GreetPeople().greeter(new String[]{"Dincso"}));
        assertEquals("HELLO, PIZZA.", new GreetPeople().greeter(new String[]{"PIZZA"}));
        assertEquals("Hello, Macko, Kata, and Balazs.", new GreetPeople().greeter(new String[]{"Macko", "Kata", "Balazs"}));
        assertEquals("HELLO, JOCI, BELA, AND TEHEN.", new GreetPeople().greeter(new String[]{"JOCI", "BELA", "TEHEN"}));
        assertEquals("Hello, Raspberry, and Chocolate. AND HELLO, DONUT, AND BOX.", new GreetPeople().greeter(new String[]{"Raspberry", "Chocolate", "DONUT", "BOX"}));
        assertEquals("Hello, Tollas, and Malac.", new GreetPeople().greeter(new String[]{"Tollas, Malac"}));
        assertEquals("HELLO, MICKEY, AND MINNIE.", new GreetPeople().greeter(new String[]{"MICKEY, MINNIE"}));
        assertEquals("Hello, Pufi, and Hapi. AND HELLO, SAPI, AND HATYI.", new GreetPeople().greeter(new String[]{"Pufi, Hapi", "SAPI, HATYI"}));
        assertEquals("Hello, Twix, Meki, and Teve. AND HELLO, CSIRKE, KACSA, AND OREO.", new GreetPeople().greeter(new String[]{"Twix", "Meki, Teve", "CSIRKE, KACSA", "OREO"}));
    }
}